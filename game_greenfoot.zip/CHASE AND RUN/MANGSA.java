import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MANGSA here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MANGSA extends Actor
{
    public MANGSA(){
        getImage().scale(50,50);
    }
    /**
     * Act - do whatever the MANGSA wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        if(Greenfoot.isKeyDown("up")) {
            setRotation(-90);
            setLocation(getX(), getY()-1);
        }
        else if(Greenfoot.isKeyDown("down")){
            setRotation(90);
            setLocation(getX(), getY()+1);
        }
        else if(Greenfoot.isKeyDown("left")){
            setRotation(180);
            setLocation(getX()-1, getY());
        }
        else if(Greenfoot.isKeyDown("right")){
            setRotation(0);
            setLocation(getX()+1, getY());
        }
        
        if(isTouching(Hunters.class)) Greenfoot.stop();

        Actor food;
        food = getOneObjectAtOffset(0,0,food.class);
        if(food != null) {
            getWorld().removeObject(food);
            getWorld().addObject(new food(),
            Greenfoot.getRandomNumber(getWorld().getWidth()), 
            Greenfoot.getRandomNumber(getWorld().getHeight()));
            World world = getWorld();
            padangPasir myWorld = (padangPasir)world;
            Counter counter =myWorld.getCounter();
            counter.addScore();

        }
    
        
    }    
}
