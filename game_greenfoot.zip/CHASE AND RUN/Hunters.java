import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Random;
/**
 * Write a description of class Hunters here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Hunters extends Actor
{
    Random random = new Random();
    int jauh;
    int posisi = 0;
    int arah;
    
    public Hunters(){
        jauh = getJauh();
        int arah = getArah();
    }
    /**
     * Act - do whatever the Hunters wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public int getJauh(){
        return random.nextInt(50)+50;
    }
    public int getArah(){
        return Greenfoot.getRandomNumber(4);
    }
    public void act() 
    {
        // Add your action code here
        posisi++;
        if (arah == 0 && posisi < jauh && getX()!=getWorld().getWidth()) setLocation(getX()+2,getY());
        else if (arah == 1 && posisi < jauh && getX()!=0) setLocation(getX()-2,getY());
        else if (arah == 2 && posisi < jauh && getY()!=getWorld().getHeight()) setLocation(getX(),getY()+2);
        else if (arah == 3 && posisi < jauh && getY()!=0) setLocation(getX(),getY()-2);
        else {
            
            arah = getArah();
            jauh = getJauh();

            posisi = 0;
        }
        
 
        
    }    
}
