import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.Random;
/**
 * Write a description of class padangPasir here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class padangPasir extends World
{
    MANGSA turtle = new MANGSA();
    Random random = new Random();

    Counter counter = new Counter();
    /**
     * Constructor for objects of class padangPasir.
     * 
     */
    public padangPasir()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        addObject(turtle, getWidth()/2, getHeight()/2);
        
        addObject(counter,50,25);
        addObject(new Hunters(), 100, 100) ;
        addObject(new Hunters(), getWidth()-100 ,100) ;
        addObject(new Hunters(), 100, getHeight()-100) ;
        addObject(new Hunters(), getWidth()-100, getHeight()-100) ;
        addObject(new food(), Greenfoot.getRandomNumber(getWidth()), 
        Greenfoot.getRandomNumber(getHeight()));
    }
    
    public Counter getCounter()
    {
        return counter;
    }
    
    public void act(){
      
        
    }
}
